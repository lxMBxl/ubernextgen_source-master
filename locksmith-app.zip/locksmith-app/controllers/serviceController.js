const Service = require('./Service');

const getServices = async (req, res) => {
  try {
    // Fetch all services from the database
    const services = await Service.find();
    res.status(200).json(services);
  } catch (error) {
    res.status(500).json({ message: 'Internal server error' });
  }
};

const searchServices = async (req, res) => {
  try {
    const { query } = req.body;

    // Search for services based on the query
    const services = await Service.find({ $text: { $search: query } });
    res.status(200).json(services);
  } catch (error) {
    res.status(500).json({ message: 'Internal server error' });
  }
};

module.exports = { getServices, searchServices };
