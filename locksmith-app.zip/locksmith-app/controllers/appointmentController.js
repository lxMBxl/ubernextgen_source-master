const Appointment = require('./Appointment');

const createAppointment = async (req, res) => {
  try {
    const { providerId, dateTime, customerId } = req.body;

    // Create a new appointment
    const appointment = new Appointment({
      providerId,
      dateTime,
      customerId,
    });

    // Save the appointment to the database
    await appointment.save();

    res.status(201).json({ message: 'Appointment created successfully', appointment });
  } catch (error) {
    res.status(500).json({ message: 'Internal server error' });
  }
};

module.exports = { createAppointment };
