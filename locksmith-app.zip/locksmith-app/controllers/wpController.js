const axios = require('axios');

// Controller function for retrieving blog posts from WordPress
const getBlogPosts = async (req, res) => {
  try {
    const response = await axios.get('https://your-wordpress-site.com/wp-json/wp/v2/posts');

    // Extract the necessary data from the response
    const blogPosts = response.data.map((post) => ({
      id: post.id,
      title: post.title.rendered,
      content: post.content.rendered,
      // Additional data as needed
    }));

    res.status(200).json({ success: true, blogPosts });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

// Controller function for displaying content from the WordPress site
const getContent = async (req, res) => {
  try {
    const { slug } = req.params;

    const response = await axios.get(`https://your-wordpress-site.com/wp-json/wp/v2/pages?slug=${slug}`);

    // Extract the necessary data from the response
    const page = response.data[0];

    const content = {
      id: page.id,
      title: page.title.rendered,
      content: page.content.rendered,
      // Additional data as needed
    };

    res.status(200).json({ success: true, content });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

module.exports = {
  getBlogPosts,
  getContent,
};
