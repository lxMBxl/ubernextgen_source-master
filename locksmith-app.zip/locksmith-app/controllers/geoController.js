const Locksmith = require('./Locksmith');

const getLocksmithsNearLocation = async (req, res) => {
  try {
    const { latitude, longitude, radius } = req.query;

    // Find locksmiths within the specified radius of the location
    const locksmiths = await Locksmith.find({
      location: {
        $near: {
          $geometry: {
            type: 'Point',
            coordinates: [parseFloat(longitude), parseFloat(latitude)],
          },
          $maxDistance: parseFloat(radius),
        },
      },
    });

    res.status(200).json({ locksmiths });
  } catch (error) {
    res.status(500).json({ message: 'Internal server error' });
  }
};

module.exports = { getLocksmithsNearLocation };
