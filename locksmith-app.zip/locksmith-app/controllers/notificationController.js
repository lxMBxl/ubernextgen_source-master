const notificationService = require('../services/notificationService');

// Controller function for sending a notification to a user
const sendNotification = async (req, res) => {
  try {
    const { userId, message } = req.body;

    // Send the notification to the user
    await notificationService.sendNotificationToUser(userId, message);

    res.status(200).json({ success: true, message: 'Notification sent to the user.' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

// Controller function for sending a notification to a locksmith
const sendLocksmithNotification = async (req, res) => {
  try {
    const { locksmithId, message } = req.body;

    // Send the notification to the locksmith
    await notificationService.sendNotificationToLocksmith(locksmithId, message);

    res.status(200).json({ success: true, message: 'Notification sent to the locksmith.' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

module.exports = {
  sendNotification,
  sendLocksmithNotification,
};
