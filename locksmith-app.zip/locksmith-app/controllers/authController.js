const { executeQuery } = require('./database');

// Middleware to authenticate the user
function authenticate(req, res, next) {
  const token = req.headers.authorization;

  if (!token) {
    return res.status(401).json({ message: 'No token provided' });
  }

  // Verify the JWT token
  jwt.verify(token, 'your_secret_key', (error, decoded) => {
    if (error) {
      return res.status(401).json({ message: 'Invalid token' });
    }

    req.user = decoded;
    next();
  });
}

// Example protected route
router.get('/profile', authenticate, async (req, res) => {
  const { email } = req.user;

  // Fetch user profile from the database
  const profileQuery = 'SELECT * FROM users WHERE email = ?';
  const profile = await executeQuery(profileQuery, [email]);

  res.status(200).json({ profile });
});

module.exports = { authenticate };
