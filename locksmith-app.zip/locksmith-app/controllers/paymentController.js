const PaymentGateway = require('./PaymentGateway');

const processPayment = async (req, res) => {
  try {
    const { amount, cardNumber, expiryDate, cvv } = req.body;

    // Perform payment processing using a payment gateway
    const paymentGateway = new PaymentGateway();
    const paymentResult = await paymentGateway.processPayment(amount, cardNumber, expiryDate, cvv);

    res.status(200).json({ message: 'Payment processed successfully', paymentResult });
  } catch (error) {
    res.status(500).json({ message: 'Internal server error' });
  }
};

module.exports = { processPayment };
