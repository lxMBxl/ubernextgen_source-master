import React, { useState, useEffect } from 'react';
import axios from 'axios';

const WordPress = () => {
  const [blogPosts, setBlogPosts] = useState([]);
  const [content, setContent] = useState(null);

  useEffect(() => {
    // Fetch blog posts when the component mounts
    fetchBlogPosts();

    // Fetch content when the component mounts (replace 'about' with the desired slug)
    fetchContent('about');
  }, []);

  const fetchBlogPosts = async () => {
    try {
      const response = await axios.get('/api/blog-posts');

      // Set the fetched blog posts in the state
      setBlogPosts(response.data.blogPosts);
    } catch (error) {
      console.log('Error fetching blog posts:', error.message);
    }
  };

  const fetchContent = async (slug) => {
    try {
      const response = await axios.get(`/api/content/${slug}`);

      // Set the fetched content in the state
      setContent(response.data.content);
    } catch (error) {
      console.log('Error fetching content:', error.message);
    }
  };

  return (
    <div>
      <h2>Blog Posts</h2>
      {blogPosts.length > 0 ? (
        <ul>
          {blogPosts.map((post) => (
            <li key={post.id}>
              <h3>{post.title}</h3>
              <div dangerouslySetInnerHTML={{ __html: post.content }} />
            </li>
          ))}
        </ul>
      ) : (
        <p>No blog posts to display.</p>
      )}

      <h2>Content</h2>
      {content ? (
        <div>
          <h3>{content.title}</h3>
          <div dangerouslySetInnerHTML={{ __html: content.content }} />
        </div>
      ) : (
        <p>No content to display.</p>
      )}
    </div>
  );
};

export default WordPress;
