const express = require('express');
const app = express();

app.get('/api/services', (req, res) => {
    // Fetch the list of services from the database and send it as a response
    // This is just a placeholder - you'll need to replace it with actual database code
    res.json([
        { id: 1, name: 'Service 1' },
        { id: 2, name: 'Service 2' },
        // etc.
    ]);
});

app.listen(3000, () => console.log('Server running on port 3000'));
