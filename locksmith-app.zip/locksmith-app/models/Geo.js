import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Geo = () => {
  const [latitude, setLatitude] = useState('');
  const [longitude, setLongitude] = useState('');
  const [radius, setRadius] = useState('');
  const [locksmiths, setLocksmiths] = useState([]);

  const handleSearch = async (e) => {
    e.preventDefault();

    try {
      // Get locksmiths near the specified location
      const response = await axios.get('/locksmiths', {
        params: {
          latitude,
          longitude,
          radius,
        },
      });

      setLocksmiths(response.data.locksmiths);
    } catch (error) {
      console.error(error.response.data); // Handle error response
    }
  };

  return (
    <div>
      <h2>Find Locksmiths Near Location</h2>
      <form onSubmit={handleSearch}>
        <label htmlFor="latitude">Latitude:</label>
        <input type="text" id="latitude" value={latitude} onChange={(e) => setLatitude(e.target.value)} required />

        <label htmlFor="longitude">Longitude:</label>
        <input type="text" id="longitude" value={longitude} onChange={(e) => setLongitude(e.target.value)} required />

        <label htmlFor="radius">Radius (in meters):</label>
        <input type="text" id="radius" value={radius} onChange={(e) => setRadius(e.target.value)} required />

        <button type="submit">Search</button>
      </form>

      {locksmiths.length > 0 && (
        <div>
          <h3>Locksmiths near the location:</h3>
          <ul>
            {locksmiths.map((locksmith) => (
              <li key={locksmith.id}>{locksmith.name}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default Geo;
