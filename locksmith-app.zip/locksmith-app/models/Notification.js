import React, { useState, useEffect } from 'react';
import { getNotifications } from '../services/notificationService';

const Notification = () => {
  const [notifications, setNotifications] = useState([]);

  useEffect(() => {
    // Fetch the notifications when the component mounts
    fetchNotifications();
  }, []);

  const fetchNotifications = async () => {
    try {
      const response = await getNotifications();

      // Set the fetched notifications in the state
      setNotifications(response.notifications);
    } catch (error) {
      console.log('Error fetching notifications:', error.message);
    }
  };

  return (
    <div>
      <h2>Notifications</h2>
      {notifications.length > 0 ? (
        <ul>
          {notifications.map((notification) => (
            <li key={notification.id}>{notification.message}</li>
          ))}
        </ul>
      ) : (
        <p>No notifications to display.</p>
      )}
    </div>
  );
};

export default Notification;
