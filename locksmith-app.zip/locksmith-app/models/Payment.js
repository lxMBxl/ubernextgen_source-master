import React, { useState } from 'react';
import axios from 'axios';

const Payment = () => {
  const [amount, setAmount] = useState('');
  const [cardNumber, setCardNumber] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [cvv, setCvv] = useState('');
  const [paymentResult, setPaymentResult] = useState('');

  const handlePayment = async (e) => {
    e.preventDefault();

    try {
      // Process payment
      const response = await axios.post('/process-payment', {
        amount,
        cardNumber,
        expiryDate,
        cvv,
      });

      setPaymentResult(response.data.paymentResult);
    } catch (error) {
      console.error(error.response.data); // Handle error response
    }
  };

  return (
    <div>
      <h2>Make a Payment</h2>
      <form onSubmit={handlePayment}>
        <label htmlFor="amount">Amount:</label>
        <input type="text" id="amount" value={amount} onChange={(e) => setAmount(e.target.value)} required />

        <label htmlFor="cardNumber">Card Number:</label>
        <input type="text" id="cardNumber" value={cardNumber} onChange={(e) => setCardNumber(e.target.value)} required />

        <label htmlFor="expiryDate">Expiry Date:</label>
        <input type="text" id="expiryDate" value={expiryDate} onChange={(e) => setExpiryDate(e.target.value)} required />

        <label htmlFor="cvv">CVV:</label>
        <input type="text" id="cvv" value={cvv} onChange={(e) => setCvv(e.target.value)} required />

        <button type="submit">Pay</button>
      </form>

      {paymentResult && (
        <div>
          <h3>Payment Result:</h3>
          <p>{paymentResult}</p>
        </div>
      )}
    </div>
  );
};

export default Payment;
