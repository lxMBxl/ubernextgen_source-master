import React, { useState } from 'react';
import axios from 'axios';

const Appointment = () => {
  const [providerId, setProviderId] = useState('');
  const [dateTime, setDateTime] = useState('');
  const [customerId, setCustomerId] = useState('');

  const handleAppointmentSubmit = async (e) => {
    e.preventDefault();

    try {
      // Create a new appointment
      const response = await axios.post('/appointments', {
        providerId,
        dateTime,
        customerId,
      });

      console.log(response.data); // Handle success response
    } catch (error) {
      console.error(error.response.data); // Handle error response
    }
  };

  return (
    <div>
      <h2>Schedule Appointment</h2>
      <form onSubmit={handleAppointmentSubmit}>
        <label htmlFor="providerId">Provider ID:</label>
        <input type="text" id="providerId" value={providerId} onChange={(e) => setProviderId(e.target.value)} required />

        <label htmlFor="dateTime">Date and Time:</label>
        <input type="datetime-local" id="dateTime" value={dateTime} onChange={(e) => setDateTime(e.target.value)} required />

        <label htmlFor="customerId">Customer ID:</label>
        <input type="text" id="customerId" value={customerId} onChange={(e) => setCustomerId(e.target.value)} required />

        <button type="submit">Schedule</button>
      </form>
    </div>
  );
};

export default Appointment;
