import React from 'react';
import ReactDOM from 'react-dom';
import App from './react-components/App';

ReactDOM.render(<App />, document.getElementById('react-app'));
