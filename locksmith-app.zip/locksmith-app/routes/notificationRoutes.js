const express = require('express');
const router = express.Router();
const notificationController = require('../controllers/notificationController');

// Route for sending a notification to a user
router.post('/send-notification', notificationController.sendNotification);

// Route for sending a notification to a locksmith
router.post('/send-locksmith-notification', notificationController.sendLocksmithNotification);

module.exports = router;
