const express = require('express');
const router = express.Router();
const geoController = require('./geoController');

router.get('/locksmiths', geoController.getLocksmithsNearLocation);

module.exports = router;
