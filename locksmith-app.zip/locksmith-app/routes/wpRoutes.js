const express = require('express');
const router = express.Router();
const wpController = require('../controllers/wpController');

// Route for retrieving blog posts from WordPress
router.get('/blog-posts', wpController.getBlogPosts);

// Route for displaying content from the WordPress site
router.get('/content/:slug', wpController.getContent);

module.exports = router;
