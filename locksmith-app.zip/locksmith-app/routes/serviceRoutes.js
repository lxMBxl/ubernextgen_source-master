const express = require('express');
const router = express.Router();
const serviceController = require('./serviceController');

router.get('/services', serviceController.getServices);
router.post('/services/search', serviceController.searchServices);

module.exports = router;
